#!/bin/bash

if [ $# -ne 0 ]; then
    echo "[*SO*] erro em faturacao.sh: número de parametros errado"
else
    echo "[*SO*] faturacao.sh ok"
fi