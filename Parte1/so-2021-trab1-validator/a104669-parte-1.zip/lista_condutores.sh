#!/bin/bash

if [ $# -ne 0 ]; then
    echo "[*SO*] erro em lista_condutores.sh: número de parametros errado"
else
    echo "[*SO*] lista_condutores.sh ok"
fi